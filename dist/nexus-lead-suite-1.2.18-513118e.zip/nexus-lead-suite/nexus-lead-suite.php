<?php
/**
 * Plugin Name:       Nexus Lead Suite
 * Plugin URI:        https://wordpress.org/plugins/nexus-lead-suite/
 * Description:       A high-performance, all-in-one lead generation and user analytics suite with a modern admin experience.
 * Version:           1.2.18
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            Nexus Lead Suite
 * Author URI:        https://github.com/Mostafijemon24
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       nexus-lead-suite
 * Domain Path:       /languages
 *
 * @package nexulesuite_
 */

declare(strict_types=1);

namespace nexulesuite_;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Hard requirement: PHP 7.4+ (avoid fatals on older hosts).
if ( defined( 'PHP_VERSION_ID' ) && PHP_VERSION_ID < 70400 ) {
	if ( is_admin() ) {
		add_action(
			'admin_notices',
			static function (): void {
				echo '<div class="notice notice-error"><p>' .
					esc_html__( 'Nexus Lead Suite requires PHP 7.4 or newer. Please upgrade PHP, then activate the plugin again.', 'nexus-lead-suite' ) .
				'</p></div>';
			}
		);
	}

	// If this is an activation attempt, rollback activation and show a clear error.
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( is_admin() && isset( $_GET['activate'] ) ) {
		deactivate_plugins( plugin_basename( __FILE__ ) );
		wp_die(
			esc_html__( 'Plugin activation failed: Nexus Lead Suite requires PHP 7.4 or newer.', 'nexus-lead-suite' ),
			esc_html__( 'Activation error', 'nexus-lead-suite' ),
			array( 'back_link' => true )
		);
	}

	return;
}

define( 'nexulesuite_VERSION', '1.2.18' );
define( 'nexulesuite_PLUGIN_FILE', __FILE__ );
define( 'nexulesuite_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'nexulesuite_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'nexulesuite_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

// No string-function polyfills are needed: WordPress core (wp-includes/compat.php)
// has provided str_starts_with(), str_contains() and str_ends_with() since
// WordPress 5.9, and this plugin requires WordPress 6.2+.

try {
	$nexulesuite_polyfills = nexulesuite_PLUGIN_DIR . 'core/polyfills.php';
	if ( file_exists( $nexulesuite_polyfills ) ) {
		require_once $nexulesuite_polyfills;
	}

	$nexulesuite_required = array(
		nexulesuite_PLUGIN_DIR . 'core/class-activator.php',
		nexulesuite_PLUGIN_DIR . 'core/class-forms-payload-codec.php',
		nexulesuite_PLUGIN_DIR . 'core/class-form-submissions-store.php',
		nexulesuite_PLUGIN_DIR . 'core/class-activities-store.php',
		nexulesuite_PLUGIN_DIR . 'core/class-data-bundle.php',
		nexulesuite_PLUGIN_DIR . 'core/class-deactivator.php',
		nexulesuite_PLUGIN_DIR . 'core/popup-shortcode-expand.php',
		nexulesuite_PLUGIN_DIR . 'core/class-plugin.php',
	);

	$nexulesuite_missing = array();
	foreach ( $nexulesuite_required as $path ) {
		if ( ! file_exists( $path ) ) {
			$nexulesuite_missing[] = $path;
		}
	}

	if ( ! empty( $nexulesuite_missing ) ) {
		if ( is_admin() ) {
			add_action(
				'admin_notices',
				static function () use ( $nexulesuite_missing ): void {
					echo '<div class="notice notice-error"><p><strong>' .
						esc_html__( 'Nexus Lead Suite installation is incomplete.', 'nexus-lead-suite' ) .
						'</strong></p><p>' .
						esc_html__( 'Some required plugin files are missing. Re-upload the full plugin folder (do not upload only a single PHP file). Missing:', 'nexus-lead-suite' ) .
						'</p><ul style="margin-left:16px;list-style:disc;">';
					foreach ( $nexulesuite_missing as $p ) {
						echo '<li><code>' . esc_html( (string) $p ) . '</code></li>';
					}
					echo '</ul></div>';
				}
			);
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( is_admin() && isset( $_GET['activate'] ) ) {
			if ( function_exists( 'deactivate_plugins' ) ) {
				deactivate_plugins( plugin_basename( __FILE__ ) );
			}
			wp_die(
				esc_html__( 'Plugin activation failed because the installation is incomplete. Missing files:', 'nexus-lead-suite' ) .
					'<br /><br /><code>' . esc_html( implode( "\n", $nexulesuite_missing ) ) . '</code>',
				esc_html__( 'Activation error', 'nexus-lead-suite' ),
				array( 'back_link' => true )
			);
		}
		return;
	}

	require_once nexulesuite_PLUGIN_DIR . 'core/class-activator.php';
	require_once nexulesuite_PLUGIN_DIR . 'core/class-forms-payload-codec.php';
	require_once nexulesuite_PLUGIN_DIR . 'core/class-form-submissions-store.php';
	require_once nexulesuite_PLUGIN_DIR . 'core/class-activities-store.php';
	require_once nexulesuite_PLUGIN_DIR . 'core/class-data-bundle.php';
	require_once nexulesuite_PLUGIN_DIR . 'core/class-deactivator.php';
	require_once nexulesuite_PLUGIN_DIR . 'core/popup-shortcode-expand.php';
	require_once nexulesuite_PLUGIN_DIR . 'core/class-plugin.php';
} catch ( \Throwable $e ) {
	if ( is_admin() ) {
		add_action(
			'admin_notices',
			static function () use ( $e ): void {
				echo '<div class="notice notice-error"><p><strong>' .
					esc_html__( 'Nexus Lead Suite could not load due to a fatal error.', 'nexus-lead-suite' ) .
					'</strong></p><p><code>' .
					esc_html( $e->getMessage() ) .
					'</code></p><p><code>' .
					esc_html( $e->getFile() . ':' . $e->getLine() ) .
					'</code></p></div>';
			}
		);
	}

	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( is_admin() && isset( $_GET['activate'] ) ) {
		if ( function_exists( 'deactivate_plugins' ) ) {
			deactivate_plugins( plugin_basename( __FILE__ ) );
		}
		if ( function_exists( 'error_log' ) && ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ) {
			error_log( '[Nexus Lead Suite] Activation load error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- logged only when WP_DEBUG is enabled.
		}
		wp_die(
			esc_html__( 'Plugin activation failed due to a fatal error:', 'nexus-lead-suite' ) .
				'<br /><br /><code>' . esc_html( $e->getMessage() ) . '</code>' .
				'<br /><code>' . esc_html( $e->getFile() . ':' . $e->getLine() ) . '</code>',
			esc_html__( 'Activation error', 'nexus-lead-suite' ),
			array( 'back_link' => true )
		);
	}
	return;
}

/**
 * Registers activation hook.
 */
register_activation_hook( __FILE__, array( Activator::class, 'activate' ) );

/**
 * Registers deactivation hook.
 */
register_deactivation_hook( __FILE__, array( Deactivator::class, 'deactivate' ) );

/**
 * Begins plugin execution.
 *
 * @return void
 */
function nexulesuite_run(): void {
	$plugin = new Plugin();
	$plugin->run();
}

try {
	nexulesuite_run();
} catch ( \Throwable $e ) {
	if ( is_admin() ) {
		add_action(
			'admin_notices',
			static function () use ( $e ): void {
				echo '<div class="notice notice-error"><p><strong>' .
					esc_html__( 'Nexus Lead Suite encountered a fatal error during boot.', 'nexus-lead-suite' ) .
					'</strong></p><p><code>' .
					esc_html( $e->getMessage() ) .
					'</code></p></div>';
			}
		);
	}

	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( is_admin() && isset( $_GET['activate'] ) ) {
		if ( function_exists( 'deactivate_plugins' ) ) {
			deactivate_plugins( plugin_basename( __FILE__ ) );
		}
		if ( function_exists( 'error_log' ) && ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ) {
			error_log( '[Nexus Lead Suite] Activation boot error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- logged only when WP_DEBUG is enabled.
		}
		wp_die(
			esc_html__( 'Plugin activation failed due to a fatal error:', 'nexus-lead-suite' ) .
				'<br /><br /><code>' . esc_html( $e->getMessage() ) . '</code>' .
				'<br /><code>' . esc_html( $e->getFile() . ':' . $e->getLine() ) . '</code>',
			esc_html__( 'Activation error', 'nexus-lead-suite' ),
			array( 'back_link' => true )
		);
	}
}
